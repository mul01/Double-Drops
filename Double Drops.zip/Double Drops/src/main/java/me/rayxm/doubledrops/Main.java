package me.rayxm.doubledrops;

import org.bukkit.plugin.java.JavaPlugin;

public final class Main extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic
        System.out.println("Plugin officially started.");

        getServer().getPluginManager().registerEvents(new BreakBlock, this);
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}
